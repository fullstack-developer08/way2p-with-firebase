import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apache-web-server',
  templateUrl: './apache-web-server.component.html',
  styleUrls: ['./apache-web-server.component.scss']
})
export class ApacheWebServerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
