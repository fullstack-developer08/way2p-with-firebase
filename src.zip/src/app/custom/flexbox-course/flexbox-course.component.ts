import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flexbox-course',
  templateUrl: './flexbox-course.component.html',
  styleUrls: ['./flexbox-course.component.scss']
})
export class FlexboxCourseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
