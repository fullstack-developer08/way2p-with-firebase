import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngrx-effects',
  templateUrl: './ngrx-effects.component.html',
  styleUrls: ['./ngrx-effects.component.scss']
})
export class NgrxEffectsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
