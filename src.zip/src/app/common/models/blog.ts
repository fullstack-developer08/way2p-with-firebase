export interface IBlog {
    id?: number;
    key?: string;
    sort?: number;
    blogTitle?: string;
    blogDesc?: string;
    blogKeyword?: string;
    blogTech?: string;
    blogName?: string;
    blogHref?: string;
    blogData?: string;
    updatedAt?: string;
}