export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyCl3BW7-1JZfk-gM4F9j58G49gIoI_3Keg",
    authDomain: "way2programming-firebase.firebaseapp.com",
    databaseURL: "https://way2programming-firebase.firebaseio.com",
    projectId: "way2programming-firebase",
    storageBucket: "way2programming-firebase.appspot.com",
    messagingSenderId: "280809409257",
    appId: "1:280809409257:web:15b25514ae296463"
  }
};
